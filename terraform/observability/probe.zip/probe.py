import json, os, socket, time, urllib.request
import boto3

def check_tcp(host, port, timeout=5):
    try:
        s = socket.create_connection((host, port), timeout=timeout)
        s.close()
        return True
    except OSError:
        return False

def put_metric(name, value, dims=None):
    cw = boto3.client("cloudwatch")
    md = {"MetricName": name, "Value": float(value), "Unit": "None",
          "Dimensions": [{"Name": k, "Value": v} for k, v in (dims or {}).items()]}
    cw.put_metric_data(Namespace="HPC/Slurm", MetricData=[md])

def handler(event, context):
    host = os.environ.get("CONTROLLER_HOST", "127.0.0.1")
    portal = os.environ.get("PORTAL_URL", "")
    ok_tcp = check_tcp(host, 6817)
    put_metric("HealthCheckStatus", 1 if ok_tcp else 0, {"Target": "slurmctld"})
    portal_ok = True
    if portal:
        try:
            urllib.request.urlopen(portal + "/healthz", timeout=5)
        except Exception:
            portal_ok = False
        put_metric("HealthCheckStatus", 1 if portal_ok else 0, {"Target": "portal"})
    return {"statusCode": 200, "body": json.dumps({"slurmctld": ok_tcp, "portal": portal_ok})}
